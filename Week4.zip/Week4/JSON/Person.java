package com.jsonexample;

import java.util.Arrays;

public class Person {
String name;
int agee;
Address[] address;

public Person () {}
public Person(String name, int age, Address[] address) {
    super();
    this.name = name;
    this.agee = age;
    this.address = address;
}



public String getName() {
    return name;
}
public void setName(String name) {
    this.name = name;
}
public int getAgee() {
    return agee;
}
public void setAgee(int age) {
    this.agee = age;
}
public Address[] getAddress() {
    return address;
}
public void setAddress(Address[] address) {
    this.address = address;
}
@Override
public String toString() {
    return "Person [name=" + name + ", agee=" + agee + ", address=" + Arrays.toString(address) + "]";
}

}
