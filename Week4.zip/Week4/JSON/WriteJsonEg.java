package com.jsonexample;
import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;
public class WriteJsonEg {
	public static void main(String[] args) throws Exception

	{
		//Address addr=new Address("Street1","City1",54657778);
		//Person obj=new Person("Ravi" ,46 ,addr);	
		//obj.setAge(46);
		//obj.setName("Ravi");
		Address[] addrs= {new Address("Street1","City1",54654),
				new Address("Street2","City2",6546553)
		};
		Person obj=new Person("Ravi" ,46 ,addrs);
		ObjectMapper mapper=new ObjectMapper();
		FileOutputStream fos=new FileOutputStream("Person.json");
		mapper.writeValue(fos,obj);
		String pjson=mapper.writeValueAsString(obj);
		System.out.println("JSON file has been created,pls check\n");
				}
	

	
}
