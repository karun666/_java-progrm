package RevisionDay3;

public class MultiThreaingEg3 {
	 public static void main(String[] args) throws InterruptedException {
	        String str = "Now, I am developing multithreaded program";

	        // Main thread
	        System.out.println("Main Thread:");
	        for (int i = 0; i < str.length(); i++) {
	            System.out.print(str.charAt(i) + " ");
	        }

	        // Child thread
	        String str2 = "Hi ,Good Morning";

	        Thread childThread = new Thread(() -> {
	            System.out.println("\nChild Thread:");
	            for (int i = 0; i < str2.length(); i++) {
	                System.out.print(str2.charAt(i) + " ");
	            }
	        });

	        childThread.start();
	        childThread.join(); // Wait for the child thread to finish
	    }

}
