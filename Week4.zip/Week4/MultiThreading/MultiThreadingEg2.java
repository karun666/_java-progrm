package RevisionDay3;

//to print characters individually from a string using multi threading concept
class PrintChars extends Thread {

	String string1 = "ChildThread";

	@Override
	public void run() {
		try {

			for (int i = 0; i < string1.length(); i++) {
				
				System.out.println(string1.charAt(i)+" Child Thread");

				Thread.sleep(30);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}

public class MultiThreadingEg2 {

	static String string1 = "MainThread";

	public static void main(String[] args) {

		try {

			PrintChars thread = new PrintChars();
			thread.start();
			for (int i = 0; i < string1.length(); i++) {
				System.out.println(string1.charAt(i)+" Main Thread ");
				Thread.sleep(25);
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
