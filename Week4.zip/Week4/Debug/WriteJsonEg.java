package com.jsonexample;
import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;
public class WriteJsonEg {
	public static void main(String[] args) throws Exception

	{
		Address addr=new Address("Street1","City1",54657778);
		Person obj=new Person("Ravi" ,46 ,addr);	
		//obj.setAge(46);
		//obj.setName("Ravi");
		
		ObjectMapper mapper=new ObjectMapper();
		FileOutputStream fos=new FileOutputStream("Person.json");
		mapper.writeValue(fos,obj);
				}
	

	
}
